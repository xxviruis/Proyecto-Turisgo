import 'package:flutter/material.dart';
import 'Screens/Principal.dart';

void main() {
  runApp(const Principal());
}

class Principal extends StatelessWidget {
  const Principal({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: PantallaPrincipal(),
      debugShowCheckedModeBanner: false,
    );
  }
}
