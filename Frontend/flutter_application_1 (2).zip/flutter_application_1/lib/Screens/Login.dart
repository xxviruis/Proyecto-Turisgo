import 'package:flutter/material.dart';
import 'package:flutter_application_1/Screens/Principal.dart';

class Login extends StatefulWidget {
  const Login({super.key});

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final email = TextEditingController();
  final password = TextEditingController();
  final key = GlobalKey<FormState>();
  bool mostrarPassword = true;
  void validar() async {
    // 1. Primero verifica que el formulario esté válido
    if (key.currentState?.validate() ?? false) {
      // 2. Opcional: mostrar un loading mientras "procesas"
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Row(
            children: [
              CircularProgressIndicator(),
              SizedBox(width: 16),
              Text("Creando cuenta..."),
            ],
          ),
          duration: Duration(seconds: 2),
        ),
      );

      // 3. Simular procesamiento (registro, llamada a API, etc.)
      await Future.delayed(
        const Duration(milliseconds: 800),
      ); // se ve más natural que 300ms

      // 4. Quitar el SnackBar (si aún está visible)
      ScaffoldMessenger.of(context).hideCurrentSnackBar();

      // 5. Navegar a la pantalla principal
      if (context.mounted) {
        // ← ¡IMPORTANTE! Evita errores si el widget ya se destruyó
        Navigator.of(context).pushReplacement(
          // ← pushReplacement es mejor que push
          MaterialPageRoute(builder: (_) => const PantallaPrincipal()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: key,
        child: Center(
          child: Container(
            width: 500,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 249, 255, 242),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: const Text(
                        "Turisgo",
                        style: TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A73E8),
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    Center(
                      child: const Text(
                        "Inicia sesión para continuar",
                        style: TextStyle(fontSize: 16, color: Colors.black54),
                      ),
                    ),
                    const SizedBox(height: 40),

                    SizedBox(
                      width: 500,
                      child: TextFormField(
                        decoration: InputDecoration(
                          labelText: "Correo Electronico",
                          prefixIcon: Icon(Icons.email_outlined),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Ingresa el correo";
                          }
                          return null;
                        },
                      ),
                    ),
                    const SizedBox(height: 20),
                    SizedBox(
                      width: 500,
                      child: TextFormField(
                        obscureText: mostrarPassword,
                        decoration: InputDecoration(
                          labelText: "Contraseña",
                          prefixIcon: Icon(Icons.lock_outline),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                mostrarPassword = !mostrarPassword;
                              });
                            },
                            icon: Icon(
                              mostrarPassword
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Ingresa la contraseña";
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 30),
                    TextButton(
                      onPressed: () {},
                      child: Text("🔑 Olvide mi contraseña"),
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      width: double.infinity,
                      height: 40,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusGeometry.circular(10),
                          ),
                        ),
                        onPressed: () {
                          validar();
                        },
                        child: Text(
                          "Ingresar",
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
