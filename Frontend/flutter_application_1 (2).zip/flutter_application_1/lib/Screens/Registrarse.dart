import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class Registro extends StatefulWidget {
  const Registro({super.key});

  @override
  State<Registro> createState() => _RegistroState();
}

class _RegistroState extends State<Registro> {
  final _key = GlobalKey<FormState>();
  final _txtEmail = TextEditingController();
  final _txtPassword = TextEditingController();
  final _txtConfirmPassword = TextEditingController();
  final _txtUsername = TextEditingController();
  final _txtPhone = TextEditingController();
  String? rolSeleccionado;
  bool mostrarPassword = true;
  bool mostrarPassword2 = true;
  final List<String> rol = ['Turista', 'Prestador de servicios'];

  String? passwordValidator(String? value) {
    if (value == null || value.isEmpty) return 'La contraseña es requerida';
    final regex = RegExp(r'^(?=.{6,}$)(?=.*[a-z])(?=.*\d).+$');
    if (!regex.hasMatch(value)) {
      return 'Mínimo 6 caracteres, al menos una minúscula y un número';
    }
    return null;
  }

  void validar() {
    if (_key.currentState!.validate()) {
      _txtUsername.clear();
      _txtEmail.clear();
      _txtPhone.clear();
      _txtPassword.clear();
      _txtConfirmPassword.clear();
      setState(() {
        rolSeleccionado = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Form(
        key: _key,
        child: Center(
          child: Container(
            width: 500,
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 249, 255, 242),
              borderRadius: BorderRadius.circular(10),
            ),
            child: SingleChildScrollView(
              child: Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: const Text(
                        "Turisgo",
                        style: TextStyle(
                          fontSize: 38,
                          fontWeight: FontWeight.bold,
                          color: Color(0xFF1A73E8),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: DropdownButtonFormField<String>(
                        value: rolSeleccionado,
                        hint: const Text(
                          "Seleccione un rol",
                          style: TextStyle(color: Colors.black),
                        ),
                        decoration: InputDecoration(
                          labelText: "Rol",
                          prefixIcon: const Icon(Icons.person_outline),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12,
                            vertical: 16,
                          ),
                        ),
                        items: rol.map((String value) {
                          return DropdownMenuItem<String>(
                            value: value,
                            child: Text(value),
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            rolSeleccionado = value;
                          });
                        },
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Por favor seleccione un rol";
                          }
                          return null;
                        },
                      ),
                    ),

                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: _txtUsername,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: "Nombre de usuario",
                          prefixIcon: Icon(Icons.person),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Por favor ingrese un nombre de usuario";
                          }
                          return null;
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: _txtEmail,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: "Correo Electronico",
                          prefixIcon: Icon(Icons.email_outlined),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                        ),
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return "Por favor ingrese un correo electronico";
                          }
                          return null;
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: _txtPhone,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          labelText: "Celular (opcional)",
                          prefixIcon: Icon(Icons.phone),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                        ),
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly,
                          LengthLimitingTextInputFormatter(10),
                        ],
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: _txtPassword,
                        obscureText: mostrarPassword,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: "Contraseña",
                          prefixIcon: Icon(Icons.password_outlined),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                mostrarPassword = !mostrarPassword;
                              });
                            },
                            icon: Icon(
                              mostrarPassword
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                        ),
                        validator: (value) {
                          return passwordValidator(value);
                        },
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: TextFormField(
                        controller: _txtConfirmPassword,
                        obscureText: mostrarPassword2,
                        keyboardType: TextInputType.text,
                        decoration: InputDecoration(
                          labelText: "Confirmar Contraseña",
                          prefixIcon: Icon(Icons.password_outlined),
                          suffixIcon: IconButton(
                            onPressed: () {
                              setState(() {
                                mostrarPassword2 = !mostrarPassword2;
                              });
                            },
                            icon: Icon(
                              mostrarPassword
                                  ? Icons.visibility_off
                                  : Icons.visibility,
                            ),
                          ),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          fillColor: Colors.white,
                          filled: true,
                        ),
                        validator: (value) {
                          if (value != _txtPassword.text) {
                            return "Las contraseñas no coinciden";
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      width: double.infinity,
                      height: 40,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.white,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadiusGeometry.circular(10),
                          ),
                        ),
                        onPressed: () {
                          validar();
                        },
                        child: Text(
                          "Registrarse",
                          style: TextStyle(color: Colors.black),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
