import 'package:flutter/material.dart';
import 'package:flutter_application_1/Screens/Login.dart';
import 'package:flutter_application_1/Screens/Registrarse.dart';

class PantallaPrincipal extends StatefulWidget {
  const PantallaPrincipal({super.key});

  @override
  State<PantallaPrincipal> createState() => _Pantalla_PrincipalState();
}

class _Pantalla_PrincipalState extends State<PantallaPrincipal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: Center(child: const Text('TURISGO')),
        backgroundColor: Colors.blue,
        actions: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: TextButton(
              style: TextButton.styleFrom(
                side: BorderSide(color: Colors.white),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusGeometry.circular(10),
                ),
                backgroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return Registro();
                    },
                  ),
                );
              },
              child: Text("Registrarse", style: TextStyle(color: Colors.black)),
            ),
          ),
          Padding(
            padding: EdgeInsetsGeometry.directional(),
            child: TextButton(
              style: TextButton.styleFrom(
                side: BorderSide(color: Colors.white),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadiusGeometry.circular(10),
                ),
                backgroundColor: Colors.white,
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return Login();
                    },
                  ),
                );
              },
              child: Text(
                "Iniciar Sesion",
                style: TextStyle(color: Colors.black),
              ),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  hintText: "¿A dónde quieres ir?",
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 14,
                  ),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                    borderSide: BorderSide.none,
                  ),
                ),
              ),
              const SizedBox(height: 25),
              const Text(
                "Categorías",
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
              ),
              const SizedBox(height: 10),
              const CategoriasCarrusel(),
              const SizedBox(height: 30),
              const Text(
                "Recomendado para ti",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              const CarruselInfinito(),
              const SizedBox(height: 30),
              const Text(
                "Hoteles populares",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              HotelesCarrusel(),
              const SizedBox(height: 30),
              const Text(
                "Restaurantes recomendados",
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 10),
              RestaurantesCarrusel(),
              const SizedBox(height: 50),
            ],
          ),
        ),
      ),
    );
  }
}

class CategoriasCarrusel extends StatefulWidget {
  const CategoriasCarrusel({super.key});

  @override
  State<CategoriasCarrusel> createState() => _CategoriasCarruselState();
}

class _CategoriasCarruselState extends State<CategoriasCarrusel> {
  final ScrollController _controller = ScrollController();

  final List<Map<String, String>> categorias = [
    {"titulo": "Hoteles", "img": "https://picsum.photos/id/100/300/200"},
    {"titulo": "Paquetes", "img": "https://picsum.photos/id/101/300/200"},
    {"titulo": "Turismo", "img": "https://picsum.photos/id/102/300/200"},
    {"titulo": "Aventura", "img": "https://picsum.photos/id/103/300/200"},
    {"titulo": "Moteles", "img": "https://picsum.photos/id/104/300/200"},
    {"titulo": "Ciudades", "img": "https://picsum.photos/id/112/300/200"},
    {"titulo": "Restaurante", "img": "https://picsum.photos/id/122/300/200"},
  ];

  late List<Map<String, String>> extendida;

  @override
  void initState() {
    super.initState();
    extendida = List.generate(40, (_) => categorias).expand((e) => e).toList();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _controller.jumpTo(_controller.position.maxScrollExtent / 2);
    });
  }

  void moverDerecha() {
    _controller.animateTo(
      _controller.offset + 260,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  void moverIzquierda() {
    _controller.animateTo(
      _controller.offset - 260,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 260,
      child: Stack(
        children: [
          ListView.builder(
            controller: _controller,
            scrollDirection: Axis.horizontal,
            itemCount: extendida.length,
            itemBuilder: (_, index) {
              final c = extendida[index];
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Container(
                  width: 220,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: const [
                      BoxShadow(
                        color: Colors.black12,
                        blurRadius: 5,
                        offset: Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      ClipRRect(
                        borderRadius: const BorderRadius.vertical(
                          top: Radius.circular(20),
                        ),
                        child: Image.network(
                          c["img"]!,
                          width: 220,
                          height: 160,
                          fit: BoxFit.cover,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        c["titulo"]!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
          Positioned(
            left: 0,
            top: 100,
            child: BotonFlecha(
              icon: Icons.arrow_back,
              onPressed: moverIzquierda,
            ),
          ),
          Positioned(
            right: 0,
            top: 100,
            child: BotonFlecha(
              icon: Icons.arrow_forward,
              onPressed: moverDerecha,
            ),
          ),
        ],
      ),
    );
  }
}

class CarruselInfinito extends StatefulWidget {
  const CarruselInfinito({super.key});

  @override
  State<CarruselInfinito> createState() => _CarruselInfinitoState();
}

class _CarruselInfinitoState extends State<CarruselInfinito> {
  final ScrollController _controller = ScrollController();
  final List<String> imagenes = [
    "https://picsum.photos/id/1018/600/350",
    "https://picsum.photos/id/1015/600/350",
    "https://picsum.photos/id/1016/600/350",
    "https://picsum.photos/id/1020/600/350",
    "https://picsum.photos/id/1035/600/350",
    "https://picsum.photos/id/1040/600/350",
  ];

  late List<String> listaExtendida;

  @override
  void initState() {
    super.initState();
    listaExtendida = List.generate(
      50,
      (_) => imagenes,
    ).expand((e) => e).toList();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _controller.jumpTo(_controller.position.maxScrollExtent / 2);
    });
  }

  void moverDerecha() {
    _controller.animateTo(
      _controller.offset + 300,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  void moverIzquierda() {
    _controller.animateTo(
      _controller.offset - 300,
      duration: const Duration(milliseconds: 300),
      curve: Curves.easeOut,
    );
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220,
      child: Stack(
        children: [
          ListView.builder(
            controller: _controller,
            scrollDirection: Axis.horizontal,
            itemCount: listaExtendida.length,
            itemBuilder: (_, index) {
              return Padding(
                padding: const EdgeInsets.all(8),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(14),
                  child: Image.network(
                    listaExtendida[index],
                    width: 260,
                    fit: BoxFit.cover,
                  ),
                ),
              );
            },
          ),
          Positioned(
            left: 0,
            top: 80,
            child: BotonFlecha(
              icon: Icons.arrow_back,
              onPressed: moverIzquierda,
            ),
          ),
          Positioned(
            right: 0,
            top: 80,
            child: BotonFlecha(
              icon: Icons.arrow_forward,
              onPressed: moverDerecha,
            ),
          ),
        ],
      ),
    );
  }
}

class BotonFlecha extends StatelessWidget {
  final IconData icon;
  final VoidCallback onPressed;

  const BotonFlecha({super.key, required this.icon, required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      backgroundColor: Colors.black45,
      child: IconButton(
        icon: Icon(icon, color: Colors.white),
        onPressed: onPressed,
      ),
    );
  }
}

class HotelesCarrusel extends StatelessWidget {
  HotelesCarrusel({super.key});

  final List<Map<String, dynamic>> hoteles = [
    {
      "img": "https://picsum.photos/id/100/500/350",
      "nombre": "Hotel Paraíso",
      "precio": 120000,
      "puntuacion": 4.5,
    },
    {
      "img": "https://picsum.photos/id/101/500/350",
      "nombre": "Royal Suites",
      "precio": 150000,
      "puntuacion": 4.8,
    },
    {
      "img": "https://picsum.photos/id/102/500/350",
      "nombre": "Hotel Vista Azul",
      "precio": 98000,
      "puntuacion": 4.3,
    },
    {
      "img": "https://picsum.photos/id/103/500/350",
      "nombre": "Dream Resort",
      "precio": 230000,
      "puntuacion": 4.9,
    },
    {
      "img": "https://picsum.photos/id/104/500/350",
      "nombre": "Hotel Montaña",
      "precio": 110000,
      "puntuacion": 4.4,
    },
    {
      "img": "https://picsum.photos/id/121/500/350",
      "nombre": "Laguna Inn",
      "precio": 87000,
      "puntuacion": 4.1,
    },
    {
      "img": "https://picsum.photos/id/106/500/350",
      "nombre": "Sol y Arena",
      "precio": 160000,
      "puntuacion": 4.7,
    },
    {
      "img": "https://picsum.photos/id/107/500/350",
      "nombre": "Caribe Palace",
      "precio": 250000,
      "puntuacion": 4.9,
    },
    {
      "img": "https://picsum.photos/id/108/500/350",
      "nombre": "Hotel Central",
      "precio": 90000,
      "puntuacion": 4.0,
    },
    {
      "img": "https://picsum.photos/id/109/500/350",
      "nombre": "Luxury Stay",
      "precio": 300000,
      "puntuacion": 5.0,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 270,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: hoteles.length,
        itemBuilder: (_, index) {
          final hotel = hoteles[index];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Container(
              width: 220,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 6,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                    child: Image.network(
                      hotel["img"],
                      height: 140,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      hotel["nombre"],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 8,
                      right: 8,
                      bottom: 8,
                    ),
                    child: Text(
                      "⭐ ${hotel["puntuacion"]} \$${hotel["precio"]} COP / noche",
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

class RestaurantesCarrusel extends StatelessWidget {
  RestaurantesCarrusel({super.key});

  final List<Map<String, dynamic>> restaurantes = [
    {
      "img": "https://picsum.photos/id/200/500/350",
      "nombre": "La Parrilla Roja",
      "precio": 35000,
      "puntuacion": 4.7,
    },
    {
      "img": "https://picsum.photos/id/201/500/350",
      "nombre": "Sabores del Mar",
      "precio": 42000,
      "puntuacion": 4.6,
    },
    {
      "img": "https://picsum.photos/id/202/500/350",
      "nombre": "Rincón Mexicano",
      "precio": 28000,
      "puntuacion": 4.4,
    },
    {
      "img": "https://picsum.photos/id/203/500/350",
      "nombre": "Pizza Italia",
      "precio": 30000,
      "puntuacion": 4.5,
    },
    {
      "img": "https://picsum.photos/id/204/500/350",
      "nombre": "Burguer House",
      "precio": 25000,
      "puntuacion": 4.2,
    },
    {
      "img": "https://picsum.photos/id/201/500/350",
      "nombre": "Café Colonial",
      "precio": 15000,
      "puntuacion": 4.8,
    },
    {
      "img": "https://picsum.photos/id/206/500/350",
      "nombre": "Sushi Master",
      "precio": 38000,
      "puntuacion": 4.9,
    },
    {
      "img": "https://picsum.photos/id/210/500/350",
      "nombre": "Donde la casa de karol",
      "precio": 45000,
      "puntuacion": 4.6,
    },
    {
      "img": "https://picsum.photos/id/208/500/350",
      "nombre": "Arepas Doña Tere",
      "precio": 12000,
      "puntuacion": 4.3,
    },
    {
      "img": "https://picsum.photos/id/209/500/350",
      "nombre": "Las Delicias",
      "precio": 18000,
      "puntuacion": 4.4,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 270,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: restaurantes.length,
        itemBuilder: (_, index) {
          final r = restaurantes[index];
          return Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Container(
              width: 220,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: const [
                  BoxShadow(
                    color: Colors.black26,
                    blurRadius: 6,
                    offset: Offset(0, 3),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ClipRRect(
                    borderRadius: const BorderRadius.vertical(
                      top: Radius.circular(16),
                    ),
                    child: Image.network(
                      r["img"],
                      height: 140,
                      width: double.infinity,
                      fit: BoxFit.cover,
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Text(
                      r["nombre"],
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.only(
                      left: 8,
                      right: 8,
                      bottom: 8,
                    ),
                    child: Text(
                      "⭐ ${r["puntuacion"]} Promedio \$${r["precio"]} COP",
                      style: const TextStyle(
                        color: Colors.black87,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
